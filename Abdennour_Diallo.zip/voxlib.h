#include <stdlib.h>

void copie(FILE* original, int file_size);
void dilater(FILE* original, int file_size);
void compresser(FILE* original, int file_size);
void grave(int16_t* buffer, int file_size, int new_file_size);
void aigue(int16_t* buffer, int file_size, int new_file_size);


